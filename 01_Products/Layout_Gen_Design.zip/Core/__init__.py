# Core package initialization
